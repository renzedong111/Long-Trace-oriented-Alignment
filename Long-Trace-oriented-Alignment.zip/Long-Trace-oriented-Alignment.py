import pm4py
import time
import copy
import os
import networkx as nx
from pm4py.algo.conformance.alignments.petri_net.variants.state_equation_a_star import get_best_worst_cost


# petri网最短路径获取
def find_shortest_path_transition_labels(net,im,fm):
    graph = nx.DiGraph()
    for transition in net.transitions:
        graph.add_node(transition.name, label=transition.label)
    for arc in net.arcs:
        graph.add_edge(arc.source.name, arc.target.name)
    start_node = next(p.name for p, tokens in im.items() if tokens > 0)
    end_node = next(p.name for p in fm)
    try:
        shortest_path = nx.shortest_path(graph, source=start_node, target=end_node)
        return [('>>', graph.nodes[node]['label'] if 'label' in graph.nodes[node] else None) for node in shortest_path if 'label' in graph.nodes[node]]
    except nx.NetworkXNoPath:
        return "No path exists between the initial and final marking."


 #面向长轨迹的对齐方法（Long-Trace-oriented-Alignment）
def reduction_case1(log,net,im,fm):
    #petri网最短路径获取
    shortest_path = find_shortest_path_transition_labels(net,im,fm)
    shortlen1 = get_best_worst_cost(net,im,fm)
    if shortlen1<10000:
        shortlen=0
    else:
        num_str = str(shortlen1)
        shortlen= int(num_str[:-4])

    #获取petri活动集合
    visible_activities = {t.label for t in net.transitions if t.label is not None}
    visible_activities_list = list(visible_activities)

    # 将事件日志转换为DataFrame并格式化
    dataframe = pm4py.convert_to_dataframe(log)
    dataframe = pm4py.format_dataframe(dataframe, case_id='case:concept:name',activity_key='concept:name', timestamp_key='time:timestamp')
    log = pm4py.convert_to_event_log(dataframe)
    trace_list = []
    for trace in log:
        current_trace=[]
        for event in trace:
            current_trace.append(event['concept:name'])
        trace_list.append(current_trace)
    # 将过滤后的事件转换为DataFrame
    filtered_dataframe = dataframe[dataframe['concept:name'].isin(visible_activities_list)]
    updated_log = pm4py.convert_to_event_log(filtered_dataframe)

    # 不完整对齐序列获取
    alignment_result = pm4py.conformance_diagnostics_alignments(updated_log, net, im, fm)
    alignment_list=[]
    for alignment in alignment_result:
        alignment_list.append(alignment['alignment'])

    # 索引获取与完全缺失轨迹对齐的插入
    i = 0
    j = 0
    index = {}
    for trace in trace_list:
        trace_index = []  # 用于记录被过滤活动的名称及其位置
        filtered_trace = []  # 存储过滤后的轨迹
        # 遍历当前轨迹中的事件
        for activity in trace:
            # 根据 petr_list 进行过滤
            if activity in visible_activities_list:
                filtered_trace.append(activity)  # 如果活动在 petr_list 中，保留
            else:
                trace_index.append((activity, len(filtered_trace)+j))  # 记录活动名称和位置
                j+=1
        if trace_index:
            index[i] = trace_index
        if all(activity not in visible_activities_list for activity in trace):
            new_alignment = []
            for activity in trace:
                new_alignment.append((activity, '>>'))
            for movement in shortest_path:
                new_alignment.append(movement)
            alignment_list.insert(i, new_alignment)
        i += 1
    n=i

    # 遍历索引信息，还原最优对齐序列
    for case_id, removed_activities in index.items():
        # 获取当前轨迹的对齐序列
        alignment = copy.deepcopy(alignment_list[case_id])
        updated_alignment = []
        visible_index = 0  # 日志中可见活动的位置索引
        alignment_pointer = 0  # 对齐序列的游标，用于遍历 alignment
        # 遍历被过滤活动的信息
        for activity_name, pos in removed_activities:
            # 遍历对齐序列，直到到达被过滤活动应插入的位置
            while visible_index < pos and alignment_pointer < len(alignment):
                align_activity, model_activity = alignment[alignment_pointer]
                updated_alignment.append((align_activity, model_activity))  # 添加当前对齐项
                if align_activity == ">>":  # 仅对日志活动更新可见索引
                    pos+= 1
                visible_index+=1
                alignment_pointer += 1
            # 插入被过滤活动的移动 (activity_name -> ">>")
            updated_alignment.append((activity_name, ">>"))
        # 补齐对齐序列中剩余的部分
        while alignment_pointer < len(alignment):
            updated_alignment.append(alignment[alignment_pointer])
            alignment_pointer += 1
        # 更新 alignment_list 中的对齐序列
        alignment_list[case_id] = updated_alignment

    # 还原对齐序列的fitness
    k=0
    alignment_list2=[]
    fitnessall=0
    for trace in trace_list:
        alignment_dict = {'alignment': None, 'cost': None, 'fitness': None}
        alignment = copy.deepcopy(alignment_list[k])
        cost1=cost2=0
        j=0
        while j<len(alignment):
            if alignment[j][0] == '>>' and alignment[j][1] == None:
                cost2 += 1
            if alignment[j][0] == '>>' and alignment[j][1] != None:
                cost1 += 1
            if alignment[j][1] == '>>':
                cost1 += 1
            j+=1
        k += 1
        fitness=1-cost1/(len(trace)+shortlen)
        cost=cost1*10000+cost2
        alignment_dict['alignment']=alignment
        alignment_dict['cost']=cost
        alignment_dict['fitness']=fitness
        alignment_list2.append(alignment_dict)
        fitnessall+=fitness
    fit=fitnessall/n #日志与模型的fitness


#可调用文件夹中的全部log，如不需要可自行修改
net_folder_path = ''
net_names = [f for f in os.listdir(net_folder_path) if os.path.isfile(os.path.join(net_folder_path, f))]

for i in range(len(net_names)):
    print(net_names[i])
    net_path = net_folder_path+"/"+net_names[i]
    log_path=""
    net, im, fm = pm4py.read_pnml(net_path)
    log = pm4py.read_xes(log_path)
    reduction_case1(log,net,im,fm)


